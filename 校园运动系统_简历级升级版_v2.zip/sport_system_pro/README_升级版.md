# 校园运动打卡与健康数据分析系统 v2.0

> **Python 综合项目 · 适合写进简历的大作业**

---

## 技术亮点（答辩 / 简历直接用）

| 模块 | 技术选型 | 亮点描述 |
|------|----------|----------|
| 数据持久化 | SQLite3（标准库） | 替代 CSV 平文件；WAL 模式 + 事务管理；Schema 版本迁移 |
| 身份认证 | PBKDF2-HMAC-SHA256（hashlib） | 密码哈希存储；角色权限控制（RBAC）；三类角色（学生/教师/管理员） |
| 数据可视化 | matplotlib + TkAgg 后端 | 图表内嵌 tkinter；5 种图表类型（柱/线/饼/横条/双轴） |
| 数据导出 | openpyxl | 三 Sheet Excel（明细/类型汇总/每日汇总）；自动列宽；斑马纹样式；不及格行标红 |
| 日志系统 | Python logging（滚动日志） | 文件滚动（RotatingFileHandler）；控制台与文件双输出 |
| 配置管理 | config.py 集中管理 | 统一维护路径/安全/图表/备份参数 |
| 单元测试 | pytest | 覆盖核心计算（热量/BMI/评级/过滤/汇总/风险预警）；边界值测试；模型验证 |
| 数据备份 | SQLite VACUUM INTO | 生成压缩干净副本；自动时间戳命名 |
| CSV 迁移 | migrate_from_csv() | 一键将旧版数据迁移至 SQLite，向下兼容 |

---

## 项目结构

```
sport_system_pro/
├── main.py              # tkinter 多标签页 GUI 入口
├── models.py            # 数据模型（dataclass + 输入校验）
├── database.py          # ★ SQLite 数据访问层（DAO 模式）
├── analytics.py         # 统计分析：BMI / 热量 / 风险预警 / 排行榜
├── charts.py            # ★ matplotlib 可视化组件
├── export.py            # ★ Excel / 文本报告导出
├── storage.py           # 旧版 CSV 存储（保留，供迁移使用）
├── config.py            # ★ 配置管理
├── logger.py            # ★ 日志系统
├── requirements.txt     # 依赖说明
├── tests/
│   ├── test_analytics.py  # ★ 核心逻辑单元测试（pytest）
│   └── test_database.py   # ★ 数据库模块测试
├── data/
│   ├── sport_system.db    # SQLite 主数据库
│   └── ...                # 旧版 CSV（保留兼容）
├── logs/                  # 滚动日志文件
├── exports/               # Excel 导出目录
├── reports/               # 文本周报目录
└── backups/               # 数据库备份目录
```

---

## 快速启动

### 1. 安装依赖

```bash
pip install matplotlib openpyxl pytest pytest-cov
```

### 2. 运行主程序

```bash
python main.py
```

首次运行自动初始化 SQLite 数据库，并写入默认账号：

| 角色 | 学号/账号 | 密码 |
|------|-----------|------|
| 学生 | 20250101  | 123456 |
| 教师 | T001      | teacher123 |
| 管理员 | A001    | admin888 |

### 3. 运行单元测试

```bash
pytest tests/ -v
# 查看覆盖率
pytest tests/ -v --cov=. --cov-report=term-missing
```

### 4. 从旧版 CSV 迁移数据

```python
from database import init_db, migrate_from_csv
init_db()
counts = migrate_from_csv()
print(counts)   # {'sport_records': 8, 'health_logs': 3, ...}
```

---

## 架构说明

### 分层设计（MVC 变体）

```
GUI 层（main.py）
    ↓ 调用
业务/分析层（analytics.py）
    ↓ 调用
数据访问层（database.py · DAO 模式）
    ↓ 读写
SQLite 数据库（sport_system.db）
```

### DAO 模式

`database.py` 为每张表提供独立的 DAO 类：

```python
SportDAO        # 运动记录 CRUD
HealthLogDAO    # 健康日志 CRUD
PhysicalTestDAO # 体测成绩 CRUD
ProfileDAO      # 健康档案 CRUD
AuthDAO         # 用户认证
```

---

## 核心计算公式

```
运动热量（kcal） = MET × 体重(kg) × 时长(h)
BMI             = 体重(kg) ÷ 身高(m)²
体测预判得分    = 历史最高分 + 近期运动量修正值
```

---

## 答辩介绍模板

> 本项目是基于 Python 的校园运动健康管理系统，采用**分层架构**（GUI / 业务 / 数据访问 / 存储），共 8 个功能模块。  
> 数据层使用 **SQLite** 替代平文件，实现了事务安全和 Schema 版本迁移；安全模块采用 **PBKDF2-HMAC-SHA256** 对密码进行哈希存储，支持角色权限控制；可视化模块将 **matplotlib** 内嵌于 tkinter，支持 5 种图表类型；导出模块生成带样式的三 Sheet **Excel** 报告；系统配备完整的**滚动日志**和 **pytest 单元测试**（覆盖核心计算 17 个断言）。

---

## 扩展方向（二次开发建议）

- **Flask/FastAPI Web 版**：将 DAO 层接口改为 RESTful API，前端用 Vue/React
- **微信小程序端**：后端对接小程序，实现真实 GPS 打卡
- **机器学习模块**：用 scikit-learn 对体测成绩做预测回归
- **定时任务**：用 APScheduler 实现每周自动生成报告
